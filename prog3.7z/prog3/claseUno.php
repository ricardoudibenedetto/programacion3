<?PHP 
echo "Clase Uno";
?>