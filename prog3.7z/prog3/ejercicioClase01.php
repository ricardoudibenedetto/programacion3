<?PHP 

function saludar($nombre){
    echo "hola $nombre";
}
 saludar('pepe');
?>