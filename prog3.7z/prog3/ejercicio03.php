<?PHP 
 $x = -3;
 $y = 15;
 $resultado = $x + $y; 
 echo  $x."<br/>".$y."<br/>".$resultado; 

?>