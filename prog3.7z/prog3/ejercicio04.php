<?PHP
$enteros=0 ;
$i; 
for($i=0 ; $i<=1000 ; $i+=2){
 $enteros += $i;
}
echo $enteros." ".$i;


?>