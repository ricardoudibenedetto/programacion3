<?PHP 
    $nombre = "Ricardo";
    $apellido ="Di Benedetto";

    $nombreCompleto = $nombre.",".$apellido.".";
    echo $nombreCompleto;

?>