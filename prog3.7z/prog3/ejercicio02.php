<?PHP 
 $x = -3;
 $y = 15;

 echo $resultado = $x + $y; 
?>